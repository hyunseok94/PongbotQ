Code from the urdf directory was taken from the Bullet 3 source code
repository https://github.com/bulletphysics/bullet3 from the directory
examples/ThirdPartyLibs/urdf.

The tinyxml code was obtained from http://sourceforge.net/projects/tinyxml/
